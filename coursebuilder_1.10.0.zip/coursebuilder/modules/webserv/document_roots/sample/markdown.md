Course Builder Web Server supports
[Markdown](https://pythonhosted.org/Markdown/index.html) --
a text-to-HTML conversion tool for web writers!

---

A First Level Header
====================

<img src='your_logo_here.png' />

A Second Level Header { #my-second-level-header }
---------------------

The name of this course is *{{ course_info.course.title }}*.

### Header 3

> This is a blockquote.
>
> This is the second paragraph in the blockquote.
>
> ## This is an H2 in a blockquote

Learn about Markdown here: [http://daringfireball.net/projects/markdown/]